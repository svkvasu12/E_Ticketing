﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityManager
{
    public static class SD
    {
        public const string Success = "Success";
        public const string Error = "Error";
    }
}
